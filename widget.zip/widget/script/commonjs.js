// 公共css
document.write(' <link rel="stylesheet" type="text/css" href="../css/dialog.css" />')
document.write(' <link rel="stylesheet" type="text/css" href="../comm/css/loading.css" />')
document.write(' <link rel="stylesheet" type="text/css" href="../css/api.css" />')
// 公共js
document.write('<script type="text/javascript" src="../script/api.js"></script>');
document.write('<script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.js"></script>')
document.write('<script type="text/javascript" src="../script/dialog.min.js"></script>')

document.write(' <script src="https://cdn.bootcss.com/dot/2.0.0-beta.0/doT.min.js"></script>')
document.write('<script type="text/javascript" src="../script/ajax.js"></script>')
document.write('<script src="https://cdn.bootcss.com/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>')
document.write('<script type="text/javascript" src="../script/is_online.js"></script>');




