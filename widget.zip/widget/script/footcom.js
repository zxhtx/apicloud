document.write(' <link rel="stylesheet" type="text/css" href="../comm/css/footer.css" />')
document.write('<script type="text/javascript" src="../comm/js/footer.js"></script>')